import React from "react";
import { View, StyleSheet,Text } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

const Icon = ({ name, size,onPress, backgroundColor,category ,color = "white",style }) => {
  return (
    <>
    <View
      style={[{
        width: 105,
        height: 105,
        borderRadius: 50,
        backgroundColor,
        justifyContent: "center",
        alignItems: "center",
        marginTop: "35%",
      },style]} 
    >
      <MaterialCommunityIcons
        name={name}
        backgroundColor={backgroundColor}
        color={color}
        size={size}
        onPress={onPress}
      ></MaterialCommunityIcons>
       <Text style={{color:"white"}}>{category}</Text>
    </View>
   
     </>
  );
};

export default Icon;
