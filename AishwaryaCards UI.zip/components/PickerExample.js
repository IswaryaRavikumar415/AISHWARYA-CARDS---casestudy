import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native'
import {Picker} from '@react-native-picker/picker';

 function PickerExample() {
    const [selectedLanguage, setSelectedLanguage] = useState();
  
      return (
         <View>
            <Picker
  selectedValue={selectedLanguage}
  onValueChange={(itemValue, itemIndex) =>
    setSelectedLanguage(itemValue)
  }>
  <Picker.Item label="Java" value="java" />
  <Picker.Item label="JavaScript" value="js" />
</Picker>
            
         </View>
      )
  
}
export default PickerExample

const styles = StyleSheet.create({
   text: {
      fontSize: 30,
      alignSelf: 'center',
      color: 'red'
   }
})