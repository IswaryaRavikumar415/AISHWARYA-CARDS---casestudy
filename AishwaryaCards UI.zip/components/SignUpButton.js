import React from "react";
import {
  Button,
  StyleSheet,
  View,
  Text,
  TouchableHighlight,
} from "react-native";
import { TouchableOpacity } from "react-native";

const SignUpButton = ({ onPress, color, str }) => {
 

  return (
    <TouchableOpacity
      style={[styles.Button, { backgroundColor: color }]}
      onPress={()=>navigation.navigate('RegisterScreen')}
    >
      <Text style={styles.text}>{str}</Text>
    </TouchableOpacity>
  );
};

export default SignUpButton;

const styles = StyleSheet.create({
  Button: {
    borderRadius: 30,
    width: 370,
    height: 60,
    alignItems: "center",
    justifyContent: "center",
    margin: 7,
  },
  text: {
    color: "white",
    alignSelf: "center",
    fontWeight: "bold",
  },
});
