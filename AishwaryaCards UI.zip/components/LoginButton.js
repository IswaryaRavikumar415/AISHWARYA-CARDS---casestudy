import React from "react";
import {
  Button,
  StyleSheet,
  View,
  Text,
  TouchableHighlight,
} from "react-native";
import { TouchableOpacity } from "react-native";

const LoginButton = ({ onPress, color, str,style }) => {
  
  return (
    <TouchableOpacity
      style={[styles.Button,style, { backgroundColor: color }]}
      onPress={onPress}
    >
      <Text style={[style,styles.text]}>{str}</Text>
    </TouchableOpacity>
  );
};

export default LoginButton;

const styles = StyleSheet.create({
  Button: {
    borderRadius: 30,
    width: 160,
    height: 35,
    alignItems: "center",
    justifyContent: "center",
    margin: 7,
  },
  text: {
    color: "white",
    alignSelf: "center",
    fontWeight: "bold",

  },
});
