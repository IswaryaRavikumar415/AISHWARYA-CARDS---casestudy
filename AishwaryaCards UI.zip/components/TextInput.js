import React, { useState } from "react";
import { SafeAreaView, StyleSheet, TextInput, View } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

const textInput = ({ icon, onChangeText, ...otherProps }) => {
  const [text, setText] = useState("");
  return (
    <SafeAreaView style={{alignItems:"center"}}>
      <View style={styles.sectionStyle}>
        <MaterialCommunityIcons
          name={icon}
          size={20}
          style={styles.imageStyle}
        />
        <TextInput onChangeText={onChangeText} {...otherProps} />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  continer: {
    flex: 1,
    alignItems: "center",
  },

  sectionStyle: {
    flexDirection: "row",
    alignItems: "center",
    //justifyContent:"center",
    //backgroundColor: "#FEFBF3",
    borderBottomWidth:2.5,
    borderBottomColor:"purple",
   // borderWidth: 0.5,
    //borderRadius: 25,
    marginVertical: 7,
    width: "90%",
  },
  imageStyle: {
    padding: 10,
    margin: 5,
    alignItems: "center",
    color:"purple"
  },
});

export default textInput;
