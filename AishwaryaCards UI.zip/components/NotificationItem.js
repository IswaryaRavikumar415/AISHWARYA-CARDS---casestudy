import React from 'react';
import { View, StyleSheet,Text } from 'react-native';
import { MaterialCommunityIcons } from "@expo/vector-icons";


function NotificationItem(props) {
  return (
<View style={{backgroundColor:"white",borderColor:"purple",borderWidth:1,height:"20%",flexDirection:"row",borderRadius:30,width:"90%",marginTop:"10%",justifyContent:"center",alignItems:"center"}}>
  <MaterialCommunityIcons name="file" color="purple"></MaterialCommunityIcons>
    <Text style={{color:"purple",marginLeft:"5%"}}>A File Received from  Aishwarya Cards</Text>
</View>
  );
}

const styles = StyleSheet.create({
  container: {}
});

export default NotificationItem;