import React from 'react';
import { View, StyleSheet,Text} from 'react-native';
import appText from './AppText';
import { MaterialCommunityIcons } from "@expo/vector-icons";
import AppText from './AppText';
function Navbar({style}) {
  return (
    <View style={[styles.container,style]}>
  <Text style= {{color:"white",fontSize:25,marginRight:"20%"}}>Aishwarya Cards...</Text>
  {/* <MaterialCommunityIcons name ='heart' color='white' size={20}></MaterialCommunityIcons> */}
  <MaterialCommunityIcons name ='tag' color='white' size={20}></MaterialCommunityIcons>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
      backgroundColor:"purple",
      height:"7%",
      width:"100%",
      borderRadius:50,
      flexDirection:"row",
      justifyContent:"center",
      alignItems:"center",
      marginTop:"10%"
  }
});

export default Navbar;