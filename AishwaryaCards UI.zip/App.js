import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import RegisterScreen from './screens/RegisterScreen';
import WelcomeScreen from './screens/WelcomeScreeen';
import LoginPage from './screens/LoginPage';
import Profile from './screens/Profile';
import EditProfile from './screens/EditProfile';
import NotificationScreen from './screens/NotificationScreen';
import NotificationItem from './components/NotificationItem';
import ThankyouScreen from './screens/ThankyouScreen';
import Navbar from './components/navbar';
import HomeScreen from './screens/HomeScreen';
import Icon from './components/Icon';
import Gallery from './screens/Gallery';
import ProductDetail from './screens/ProductDetail';
import Cart from './screens/Cart';
import Wishlist from './screens/Wishlist';
import ProofChecking from './screens/ProofChecking';
import Navigation from './Navigation/navigation';
import AdminPage from "./screens/AdminPage";
export default function App() {
  return (
    <View style={styles.container}>
      {/*  <WelcomeScreen /> 
      <RegisterScreen />
      <LoginPage />
      <Profile />
      <EditProfile />
      <NotificationScreen />
      <NotificationItem />
      <ThankyouScreen />
      <Navbar />
      <HomeScreen />
      <Gallery />
      <ProductDetail />
      <Cart />
      <Wishlist />
      <ProofChecking />
      
       <StatusBar style="auto" /> */}
      <Navigation />
       {/* <AdminPage /> */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    /* backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    width: "100%" */
  },
});
