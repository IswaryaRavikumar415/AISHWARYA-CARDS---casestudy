import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import AdminPage from "../screens/AdminPage";
import RegisterScreen from '../screens/RegisterScreen';
import WelcomeScreen from '../screens/WelcomeScreeen';
import LoginPage from '../screens/LoginPage';
import Profile from '../screens/Profile';
import EditProfile from '../screens/EditProfile';
import NotificationScreen from '../screens/NotificationScreen';
// import NotificationItem from './components/NotificationItem';
import ThankyouScreen from '../screens/ThankyouScreen';
import HomeScreen from '../screens/HomeScreen';
// import Icon from './components/Icon';
import Gallery from '../screens/Gallery';
import ProductDetail from '../screens/ProductDetail';
import Cart from '../screens/Cart';
import Wishlist from '../screens/Wishlist';
import ProofChecking from '../screens/ProofChecking';

const Stack = createNativeStackNavigator()
const Navigation = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Welcome"
        screenOptions={{
          headerShown: false
        }}>
        <Stack.Screen name="Welcome" component={WelcomeScreen} />
        <Stack.Screen name="RegisterScreen" component={RegisterScreen} />
        <Stack.Screen name="LoginPage" component={LoginPage} />
        <Stack.Screen name="Profile" component={Profile} />
        <Stack.Screen name="EditProfile" component={EditProfile} />
        <Stack.Screen name="NotificationScreen" component={NotificationScreen} />
        <Stack.Screen name="ThankyouScreen" component={ThankyouScreen} />
        <Stack.Screen name="Gallery" component={Gallery} />
        <Stack.Screen name="ProductDetail" component={ProductDetail} />
        <Stack.Screen name="HomeScreen" component={HomeScreen} />
        <Stack.Screen name="Cart" component={Cart} />
        <Stack.Screen name="Wishlist" component={Wishlist} />
        <Stack.Screen name="ProofChecking" component={ProofChecking} />
        <Stack.Screen name="AdminPage" component={AdminPage} />
      </Stack.Navigator>
    </NavigationContainer>
  )
}

export default Navigation;