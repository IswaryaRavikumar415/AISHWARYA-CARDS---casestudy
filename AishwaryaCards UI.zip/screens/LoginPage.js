import React from "react";
import { View, StyleSheet, Text } from "react-native";
import TextInput from "../components/TextInput";
import colors from "../app/color";
import LoginButton from "../components/LoginButton";
import { Formik } from "formik";
//import { LoginForm } from "../app/LoginForm";
import ErrorMsg from "../components/ErrorMsg";
const LoginPage = ({ navigation }) => {
  const onTouch = () => {
    console.log('to signup');
    navigation.navigate('RegisterScreen')
  }
  return (
    <Formik
      initialValues={{ Name: "", Email: "", Password: "" }}
      onSubmit={(values) => {
        console.log(values)
        navigation.navigate("ProductDetail")
      }}
    //   validationSchema={LoginForm}
    >
      {({ handleChange, handleSubmit, errors, setFieldTouched, touched }) => (
        <React.Fragment>

          <View style={styles.continer}>

            <TextInput
              icon="email-multiple"
              placeholder="Enter Your Email"
              keyboardType="email-address"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("Email")}
              onBlur={() => setFieldTouched("Email")}
            />
            {touched.Email && errors.Email ? (
              <ErrorMsg err={errors.Email} />
            ) : null}
            <TextInput
              icon="lock"
              placeholder="Enter Your Password"
              keyboardType="default"
              underlineColorAndroid="transparent"
              secureTextEntry={true}
              onChangeText={handleChange("Password")}
              onBlur={() => setFieldTouched("Password")}
            />
            {touched.Password && errors.Password ? (
              <ErrorMsg err={errors.Password} />
            ) : null}


            <TextInput
              icon="account"
              placeholder="Enter Usertype"
              keyboardType="default"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("Usertype")}
              onBlur={() => setFieldTouched("Usertype")}
            />
            {touched.Usertype && errors.Usertype ? (
              <ErrorMsg err={errors.Usertype} />
            ) : null}

            <View style={styles.btn}>
              <LoginButton
                str="SUBMIT"
                color={colors.primary}
                onPress={handleSubmit}
              />
              <LoginButton
                str="CANCEL"
                color={colors.primary}
                onPress={handleSubmit}
              />
            </View>
            <Text style={{ color: "purple", fontSize: 20, alignSelf: "center", marginTop: "10%" }} onPress={() => onTouch()}>Dont have a account Sign up ....</Text>
          </View>
        </React.Fragment>
      )}
    </Formik>
  );
};

export default LoginPage;
const styles = StyleSheet.create({
  continer: {
    flex: 1,
    paddingTop: "35%",
    padding: 7,
    backgroundColor: "#FFDEFA"
  },
  btn: {
    alignItems: "center",
    paddingTop: 25,
    flexDirection: "row"
  },
});
