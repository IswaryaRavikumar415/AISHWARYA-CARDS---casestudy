import React from 'react';
import { View, StyleSheet, ImageBackground, Text} from 'react-native';
import Screen from '../components/Screen';
import { MaterialCommunityIcons } from "@expo/vector-icons";
import AppText from '../components/AppText';
function ThankyouScreen(props) {
  return (
 <Screen style={{justfyContent:"center",alignItem:"center"}}>
    
    <View style={styles.container}>

    <MaterialCommunityIcons name="heart" size={150} color="red"  />
    
        <AppText>Order confirmed</AppText>
        <AppText>Thanks for Ordering.....</AppText>
    </View>
    <AppText style={{marginTop:"10%",color:"purple"}}>We will contact you soon...</AppText>
    </Screen> 
    

  );
}

const styles = StyleSheet.create({
  container: {
      height:"60%",
      width:"85%",
      backgroundColor:"purple",
      alignSelf:"center",
      marginTop:"50%",
      borderRadius:30,
      justifyContent:"center",
      alignItems:"center"

  }
});

export default ThankyouScreen;