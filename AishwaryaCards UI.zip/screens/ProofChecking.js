import React from 'react';
import { View, StyleSheet, Text, Image, Button } from 'react-native';
import Navbar from '../components/navbar';
import AppText from '../components/AppText';
import LoginButton from '../components/LoginButton';

function ProofChecking({ navigation }) {
  return (
    <View style={styles.container}>
      <Navbar />
      <AppText style={{ color: "purple", marginTop: "7%" }}>ProofChecking</AppText>
      <View style={{ backgroundColor: "white", height: "30%", width: "88%", borderRadius: 30, marginTop: "3%", justifyContent: "center", alignItems: "center" }}>
        <Text>Aishwarya Cards</Text>
        <Text style={{ color: "purple", marginTop: "7%", }}>Go to Order</Text>
        <LoginButton str='Upload Content' color="purple" onPress={() => navigation.navigate('Cart')}></LoginButton>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: "#FFDEFA",
    width: "100%",
  }
});

export default ProofChecking;