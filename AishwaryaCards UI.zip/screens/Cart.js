import React from 'react';
import { View, StyleSheet, Image, Text, TextInput, Button } from 'react-native';
import Navbar from '../components/navbar';
import LoginButton from '../components/LoginButton';
import PickerExample from '../components/PickerExample';
import textInput from '../components/TextInput';

function Cart({ navigation }) {
  return (
    <View style={styles.container}>
      <Navbar />
      <View style={{ flexDirection: "row" }}>
        <LoginButton str='Upload Content' color="purple" onPress={() => navigation.navigate('ProofChecking')}></LoginButton>

        <TextInput
          //icon="email-multiple"
          placeholder="Enter Quantity"
          keyboardType="number-pad"
          underlineColorAndroid="purple"
          //onChangeText={handleChange("Email")}
         // onBlur={() => setFieldTouched("Email")}
        />
        <LoginButton str='OK' color="purple" style={styles.okbutton} onPress={() => navigation.navigate('ThankyouScreen')}></LoginButton>
      </View>
      <View style={styles.splits}>
        <Image style={styles.tinyLogo} source={{ uri: 'https://www.menakacard.in/media/catalog/product/cache/1/small_image/250x250/9df78eab33525d08d6e5fb8d27136e95/s/l/sl-3070_cover_inserts.jpg', }} />
      </View>
      <View style={{ marginTop: "3%", marginLeft: "2%", marginRight: "2%" }}>
        <Text>Instructions to follow:</Text>
        <Text>Select the required quantity for your favourite item and upload the contents for proof cecking and printing works your final mount is available in the above tabulur column . If you have any doubts in ordering the item immediately contact us throogh the contact informations given below

        </Text>
      </View>

<View style={{marginTop:"10%",backgroundColor: "white",height:"16%", width:"70%",alignItems: "center", justifyContent:"center", borderRadius:20}}>
<Text style={{color:"purple",fontSize:22}}>Invitation Charge:    1000</Text><Text style={{color:"purple",fontSize:22}}>Designing Charge:    200</Text><Text style={{color:"purple",fontSize:22}}>Printing Charge:     2000</Text><Text style={{color:"black",fontSize:22}}>Total Amount:        3200</Text>
</View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFDEFA",
    width: "100%",
    alignItems: "center"

  },
  tinyLogo: {
    width: 300,
    height: 170,
    resizeMode: "stretch"
  },

  okbutton: {
    width: "21%"
  },

  splits: {
    backgroundColor: "white",
    width: "95%",
    height: "38%",
    marginTop: "5%",
    justifyContent: "center",
    // flexDirection:"row",
    alignItems: "center"
  },
});

export default Cart;