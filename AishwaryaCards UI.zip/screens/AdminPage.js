import React from "react";
import { View, StyleSheet, Text, Button } from "react-native";
import TextInput from "../components/TextInput";
import colors from "../app/color";
import LoginButton from "../components/LoginButton";
import { Formik } from "formik";
//import { LoginForm } from "../app/LoginForm";
import ErrorMsg from "../components/ErrorMsg";
import { useNavigation } from '@react-navigation/native';

const AdminPage = () => {

  const SubmitHandler = (values) => {
    console.log(values)    
     //navigation.navigate("HomeScreen")
  }

  return (
    <Formik
      initialValues={{ Category: "", Price: "", Colour: "", ItemDetail:"", PriceDetails:"", Image:""}}
      onSubmit={SubmitHandler}
    //   validationSchema={LoginForm}

    >
      {({ handleChange, handleSubmit, errors, setFieldTouched, touched }) => (
        <React.Fragment>
       
          <View style={styles.continer}>
           <Text style={{color:"purple", fontSize:24, alignSelf:"center"}}>ADMIN PAGE</Text>
            <TextInput
              icon="apps"
              placeholder="Enter Your category"
              placeholderColor="purple"
              keyboardType="default"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("Category")}
              onBlur={() => setFieldTouched("Category")}
            />
            {touched.Category && errors.Category ? (
              <ErrorMsg err={errors.Category} />
            ) : null}

            <TextInput
              icon="card"
              placeholder="Enter Your Price"
              keyboardType="email-address"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("Price")}
              onBlur={() => setFieldTouched("Price")}
            />
            {touched.Price && errors.Price ? (
              <ErrorMsg err={errors.Price} />
            ) : null}

            <TextInput
              icon="note"
              placeholder="Enter Your Colour"
              keyboardType="default"
              underlineColorAndroid="transparent"
              secureTextEntry={true}
              onChangeText={handleChange("Colour")}
              onBlur={() => setFieldTouched("Colour")}
            />
            {touched.Colour && errors.Colour ? (
              <ErrorMsg err={errors.Colour} />
            ) : null}

            <TextInput
              icon="folder"
              placeholder="Enter Your ItemDetail"
              keyboardType="default"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("ItemDetail")}
              onBlur={() => setFieldTouched("ItemDetail")}
            />
            {touched.ItemDetail && errors.ItemDetail ? (
              <ErrorMsg err={errors.ItemDetail} />
            ) : null}

            <TextInput
              icon="file"
              placeholder="Enter Your PriceDetails"
              keyboardType="default"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("PriceDetails")}
              onBlur={() => setFieldTouched("PriceDetails")}
            />
            {touched.PriceDetails && errors.PriceDetails ? (
              <ErrorMsg err={errors.PriceDetails} />
            ) : null}

             <TextInput
              icon="image"
              placeholder="Enter Your Image"
              keyboardType="default"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("Image")}
              onBlur={() => setFieldTouched("Image")}
            />
            {touched.Image && errors.Image ? (
              <ErrorMsg err={errors.Image} />
            ) : null}

            <View style={styles.btn}>
              <LoginButton
                str="Upload Product"
                color={colors.primary}
                onPress={handleSubmit}
              />
              <LoginButton
                str="CANCEL"
                color={colors.primary}
                onPress={handleSubmit}
              />
            </View>
{/* <Button
                title="VISIT APP"
                color={colors.primary}
                onPress={SubmitHandler}
              /> */}

          </View>
        </React.Fragment>
      )}
    </Formik>
  );
};

export default AdminPage;
const styles = StyleSheet.create({
  continer: {
    flex: 1,
    paddingTop: "35%",
    padding: 7,
    backgroundColor: "#FFDEFA",
    // width:"%"
  },
  btn: {
    alignItems: "center",
    paddingTop: 25,
    flexDirection: "row"

  },
});
