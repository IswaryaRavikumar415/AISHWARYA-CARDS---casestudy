import React from 'react';
import { View, StyleSheet,ScrollView,Button,Image} from 'react-native';
import Navbar from '../components/navbar';
import Loginbutton from '../components/LoginButton'
//import {Dropdown } from 'react-native-material-dropdown';

function Gallery({navigation}) {
  let data=[{value:"100"},{value:"200"},{value:"300"}]
   const SubmitHandler = () => {   
    navigation.navigate("ProductDetail")
   //console.log("hiiiii")
 }
  return (
    <View style={styles.container}>
        <Navbar />
        {/* <Dropdown label="Select price" data={data} ></Dropdown> */}
        <ScrollView>
        <View style={styles.outerContainer}>

        <View style={styles.galleryContainer}>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo}  source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/hindu-wedding-cards.jpg',}}/>
        <Button title="View Details" onPress={SubmitHandler} color="purple"></Button>
        </View>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/christian-wedding-cards.jpg',}}/>
        <Button title="View Details" onPress={SubmitHandler} color="purple"></Button>
        </View>
        
          </View>

          <View style={styles.galleryContainer}>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/muslim-wedding-cards.jpg',}}/>
        <Button title="View Details" color="purple" onPress={SubmitHandler}></Button>
        </View>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/SCROLL-INVITATIONS.jpg',}}/>
        <Button title="View Details" color="purple" onPress={SubmitHandler}></Button>
        </View>
          </View>

          <View style={styles.galleryContainer}>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/thamboolam-bags.jpg',}}/>
        <Button title="View Details" color="purple"onPress={SubmitHandler} ></Button>
        </View>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/addon-items.jpg',}}/>
        <Button title="View Details" color="purple" onPress={SubmitHandler}></Button>
        </View>
          </View>

          <View style={styles.galleryContainer}>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} resizeMode="cover" source={{uri: 'https://www.menakacard.in/media/catalog/product/cache/1/small_image/250x250/9df78eab33525d08d6e5fb8d27136e95/s/l/sl-2744_cover_pouch.jpg',}}/>
        <Button title="View Details" color="purple"onPress={SubmitHandler} ></Button>
        </View>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/catalog/product/cache/1/small_image/250x250/9df78eab33525d08d6e5fb8d27136e95/s/l/sl-3070_cover_inserts.jpg',}}/>
        <Button title="View Details" color="purple" onPress={SubmitHandler}></Button>
        </View>
          </View>

          </View>
          </ScrollView>
          
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
      flex:1,
      backgroundColor:"#FFDEFA",
      width:"100%",
      alignItems:"center"
  },
  galleryContainer:{
    marginTop:"5%",
    flexDirection:"row",
   
  },
  galleryContainer2:{
    height:300,
    width:155,
    backgroundColor:"white",
    marginTop:"5%",
    marginLeft:"3%",
    marginRight:"3%",
    justifyContent:"space-evenly"
  },
  outerContainer:{
    alignItems:"center",
    justifyContent:"center"
  },
  button:{
    marginVertical:""
  },
  tinyLogo: {
    width: 155,
    height: 250,
    resizeMode:"stretch"
  },
});

export default Gallery;