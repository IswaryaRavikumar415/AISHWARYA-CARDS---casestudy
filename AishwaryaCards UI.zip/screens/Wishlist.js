import React from 'react';
import { View, StyleSheet, Text, Image, Button} from 'react-native';
import Navbar from '../components/navbar';
import AppText from '../components/AppText';

function Wishlist(props) {
  return (
    <View style={styles.container}>
        <Navbar />
        <AppText style={{color:"purple", marginTop:"7%"}}>Wishlist</AppText>
<View style={{backgroundColor:"white",height:"50%",width:"88%",borderRadius:30,justifyContent:"center",alignItems:"center"}}>
       <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/hindu-wedding-cards.jpg',}}/>
        
        <Text style={{color:"purple", marginTop:"7%",marginBottom:"2%"}}>This semi-ethnic magenta, off-white/cream and gold card resembles loosely a classy sari like finish, reflected in the pretty gold ink borders</Text>
        <Button title="Remove wishlist" color="purple"></Button>
</View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
      flex:1,
     //justifyContent:"center",
      alignItems:"center",
      backgroundColor:"#FFDEFA",
      width:"100%",
  },
  galleryContainer:{
    marginTop:"5%",
    flexDirection:"row",
   
  },
  galleryContainer2:{
    height:300,
    width:155,
    backgroundColor:"white",
    marginTop:"5%",
    marginLeft:"3%",
    marginRight:"3%",
    justifyContent:"space-evenly"
  },
  tinyLogo: {
    width: 175,
    height: 180,
    resizeMode:"contain",
    marginLeft:"6%",
    //marginTop:"3%"
  },
});

export default Wishlist;