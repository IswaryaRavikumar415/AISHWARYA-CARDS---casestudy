import React from 'react';
import { View, StyleSheet } from 'react-native';
import AppText from '../components/AppText';
import Screen from '../components/Screen';
import { MaterialCommunityIcons } from "@expo/vector-icons";
import NotificationItem from '../components/NotificationItem';

function NotificationScreen(props) {
  return (
    
<Screen style={styles.container1}>
 <View style={styles.container}>
     <AppText style={{color:"white",marginRight:40}}>NOTIFICATIONS</AppText>
     <MaterialCommunityIcons name='bell' color="white" size={30} />
 </View>
<NotificationItem />
<NotificationItem />


</Screen>
  );
}

const styles = StyleSheet.create({
  container: {
      height:"15%",
      width:"88%",
      backgroundColor:"purple",
      marginTop:"10%",
      alignItems:"center",
      borderRadius:50,
      justifyContent:"center",
      flexDirection:"row"
  },
  container1:{
    alignItems:"center"

  }
});

export default NotificationScreen;