import React from 'react';
import { View, StyleSheet, ScrollView, Image, Text } from 'react-native';
import Navbar from '../components/navbar';
import LoginButton from '../components/LoginButton';


function ProductDetail({ props, navigation }) {
  return (
    
    <View style={styles.container}>
      <Navbar />

      <View style={{ flexDirection: "row" }}>
        <LoginButton str='Wishlist' color="purple" onPress={() => navigation.navigate('Wishlist')}></LoginButton>
        <LoginButton str='Place Order' color="purple" onPress={() => navigation.navigate('Cart')} ></LoginButton>
      </View>

      <View style={styles.splits}>
        <Image style={styles.tinyLogo} source={{ uri: 'https://www.menakacard.in/media/catalog/product/cache/1/small_image/250x250/9df78eab33525d08d6e5fb8d27136e95/s/l/sl-3070_cover_inserts.jpg', }} />
      </View>

      <View style={styles.splits} >
        <Text >This simple but elegant single card and cover is made from a classy royal blue shimmer board with the content printed in rich gold ink and is generally used for arangetram invitations. The sides of the card are decorated with the mudras of dance or instruments for musical arangetrams in contrasting blue ink on solid gold strips on either side. The enevlope is a simple cover that has contrasting gold ink content and a beautiful border at the bottom decorated with the symbols for the art form.</Text>
      </View>

      <View style={{ backgroundColor: "purple", height: 50, width: 340,marginTop:"-20%", justifyContent: "center", alignItems: "center" }}>
        <Text>Rs.30/-</Text>
      </View>
      
    </View>



  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFDEFA",
    width: "100%",

    alignItems: "center"
  },
  splits: {
    backgroundColor: "white",
    width: "95%",
    height: "38%",
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center"
  },
  
  tinyLogo: {
    width: 300,
    height: 230,
    resizeMode: "stretch"
  },

  });

export default ProductDetail;