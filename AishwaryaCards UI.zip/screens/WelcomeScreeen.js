import { ImageBackground, View, Image, Text, StyleSheet } from "react-native";
import React from "react";
import Apptext from "../components/AppText";
import colors from "../app/color";
import LoginButton from "../components/LoginButton";
const WelcomeScreen = ({ navigation }) => {

  const onSubmit = () => {
    console.log("click");
    navigation.navigate('LoginPage')

  }
  return (

    <View style={{ flex: 1, width: "100%" }}>
      <ImageBackground
        style={styles.container}
        source={require("../assets/bg.jpg")}

      >
        <Apptext style={{ marginTop: "20%", color: "purple", fontSize: 29, }}>Welcome to Aishwarya Cards</Apptext>
        <View style={{
          marginTop: "90%",
          height: "90%",
          paddingTop: 80,
        }}
        >
          <LoginButton str="Click Here..." color={colors.primary} onPress={() => onSubmit()}>

          </LoginButton>

        </View>
      </ImageBackground>
    </View>
  );
};
export default WelcomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center",
    paddingTop: 100,
    width: "100%"
  },

  text: {
    paddingTop: 10,
    justifyContent: "center",
  },
  color: {
    flex: 0.1,
  },
});
