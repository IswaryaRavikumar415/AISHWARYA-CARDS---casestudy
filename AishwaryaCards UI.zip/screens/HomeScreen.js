import React from 'react';
import { View, StyleSheet,Image, ScrollView, Button } from 'react-native';
import Navbar from '../components/navbar';
import Icon from '../components/Icon';
import LoginButton from '../components/LoginButton';

function HomeScreen({navigation}) {

  const SubmitHandler = () => {   
    navigation.navigate("Gallery")
   //console.log("hiiiii")
 }

 const SubmitHandler2 = () => {   
    navigation.navigate("NotificationScreen")
   //console.log("hiiiii")
 }

 const SubmitHandler3 = () => {   
    navigation.navigate("Wishlist")
   //console.log("hiiiii")
 }

const SubmitHandler4 = () => {   
    navigation.navigate("AdminPage")
   //console.log("hiiiii")
 }

  return (
    <View style={styles.container}>
        <Navbar />
        <View style={{flexDirection:"row"}}>
   <LoginButton str='Notificatons' color="purple" onPress={SubmitHandler2}></LoginButton>
   <LoginButton str='wishlist' color="purple"  onPress={SubmitHandler3}></LoginButton>
   {/* <LoginButton str='Admin Page' color="purple"  onPress={SubmitHandler4}></LoginButton> */}
   </View>

   <ScrollView>
   <Image style={styles.tinyLogo2}  source={{uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExIWFRUVGR4ZGBgYGBoYHxwhIRseIh8fHyAgHiogHSElHx0aITEhJikrLi8uGB8zODMsNygtLisBCgoKDg0OGxAQGy8lICYwLS03LTIvLS01LS01LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAJgBTAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAABgQFBwMCAQj/xABDEAACAgAEBAQEAwYDBwMFAQABAgMRAAQSIQUGMUETIlFhBzJxgRSRoSNCUmKx8BVy0TOCkqKyweFDU9IXJCU0kxb/xAAZAQADAQEBAAAAAAAAAAAAAAAAAgMEAQX/xAAwEQABAwIEBAYCAgMBAQAAAAABAAIRAyESMUFRBGFxgRMikaHB8LHR4fEUMkJSBf/aAAwDAQACEQMRAD8A3HBgwYEIwYMGBCMGOL7/AEx2wIRgwYMCEYMGDAhGDETP5oRRPKQWCKWIUWSAL2Hrj7kc2ssayL0YWLx3CYnRNgdhxRbKealYiHOpbLqFpWoDer3F17b1iSxwlcJ5gC+Kk8bQMkr6nZSscluadZCNJsVtdj6Ym8xFwOv9hcATSM8rR+IluAfQj69RfTE7FbwvMs2oMLAPlfamUixX0usWGsYdcXrBgwYEIwYMGBCMGDBgQjBgwYEIwYMGBCMGDHlmwIXrBjlEtXjrgQjBgwYEIwYMGBCMGPl4+4EIwYMGBCMGPOvADeBC9YMGDAhGDBgwIURZJPEKsg0dVYH23BGOzNiDxeRwgCmi7Kmr+HUaLfUdvcjEPNcdy+Wkgy7uQ8pCIN2PShq6kXsLPU/Q47CcMJAi+duQ1+7K6C45ZvORxC5JEjHqzBR+uJK4RuaOUpJZnkiIPiBQwZq0ldrH8pWth3v124rcHSpVaoZVfgbv97+idYZQyhlNhgCD6g9MdcV/BonSCJJK8REVW0mwSAASLA2PXFZzZLOkYfLUZWDxoGJ0lipZbHQm0oX3atgThmtkwoMZidhHP2Epe+IPxJXJSLlsuizZkkFwb0xr13rcsRuB2G57A9eGfFTIuIVkYxSSgllO6xkNp87dgSCQa6bmhhIl4QOHJEc0jyZrOEmR6LFTYIiU9GdidTUdyoqwMVsXKaxsZc1tuJZwNwijcpt1IXy36nHo0uEpPpgk3uewHycpW2nwrH08WK/mJ6AfvLdfodTePKRgCgK+mMlyPNfEOKZllyMq5TJwbvMyK7v7BWsb9gKobk7hcOXw55kfPZTxZFCyI5jetgSADY+oYfe8ef4bsOLp7rFhMSunxFaUcPnMQYsNJIXroDqX/wCQNfteFzIcQyvFYBCjsNCgNGSA6+/ow9xY+nTGknGWfEPl3LxN+Iysn4XOArIlBgjtqIF0KUm2BPQ35tjeIOoCo8HDPL9JqYcfK2ZzstG4dAERVA2UAD6AViYAPTHhBQ3+9euPt2dsUU0XXXpjzDKGUMpsMLB9sewMVnM2aMWTzMqGmjhkdT6FUJB+1X9scQBJSlzhzDm1mMWUzEPlHmUQs8instlijE+gWx6YZeT5M02VjOcFTb6rCqSNR0khdgStWNvoOmFSHlkwcOJyU6tmJFDNmL1FlO7eG37ti6Ybn6kENfKPFzmstHKQbIosVKB621qD+63UY6yjUweK4jOI2tYnr1WniK3DwKNFptfEczvbIDbUq+wYquOLmDEfwxQS2K17Cr33o1Q36HpXXfFjEDQ1Vdb10vvXtjsWmeyyzeFA4fxWOYnQejED+ajRI9Rd/leLPCTzNy7IIlGUWtJoKDpK2eoPoL+ow25OJkRVZy7KoBY1bEDcmvXFarKYAcwzOmo69Vm4erWc5zarYjXQj7/MFScGOUzEDyrqPpYH5+2DxBZA6j+/7GIrUvbtWKY8wQWAHLW1DRHI4u66qpFX36e+PfMTN+Gn0adfhtp1GlJrYE2KB6XY6jGbzZ6DOzxK0r5ZZAF8AoQ+rppBFoFPYn6VidU1AJptk9YtvkU2CoWF1NhdGxjCNz5XW9Oq15Btj1iLkIAkaopYhRQLMWP3JJJxKxRKjBip41xYQ+GqoZJZW0xxg0TW7En91VXct9B1IBn5eTUqkqVJAJU1YsdDW1jpjmITCF3wY8O1Anc16b455bMK6hlNg/boaP646hfJpipA0+U3bWAF+uPGUz0Uurw5EfSabQwaj6GjsfbFPmI4pc6Y5ZAdEKssJNXbNqkI/e+VV9qN/MMXeXiVFCooVR0CgAD6AbYYgRzTkMDRe/t+ZPoO6kY8Hf6Y9N0x5HT+/XCpEH3GAitxgZsBvAhegcfcfAMfcCEY5Mft+mOuPBTAhcZYg6lWAKkUQRdg9iO+M04vkpshmXfK5DxlejEUPysQA5kJJIutj0o1YxoD5Wfxg6z1FVNEUBvY7hrsb+2Kfh/EWzWalK7ZaEeGp/8AckJtm+igUB/PfcV1aqQexrnMMjD5s9TGEzFydpBE3iUvcH4txcDMTZnwgsCa/AWI04okhZNVhgB6OPWjh/4VnknhjmT5ZFDC+osdD7jofpit43MI8rmGq6ifb1OkgD7mh98UvIGecZZpcw4ih1aYFkpNKiyzEmjbMX67aUWu9hc0m3p8pMLDRL5GLELciDzmxET7pzGYXVo1LqAsrYuvWuvcfnjlncmkoAcWFdXG5FMrBlO3uOnfocZjx34i8Ohzfi5bx8zORoKwgCN9qAJYWT0ooD8ow8cpcyrnMsJ2QQsCVkQvq0Edi1C7FHoOuFxCUjmgQWzkJtEHbpzV5JEG2IBo3/5xhee5bz02aOXzjiCCSUu8usaJLawsZPViexqiASOgOn8V4BNJm0nEyCNSgKFSGCqbNMDuSSewG/fEP4h8ujOoirmFicWqhhYOoi+m97D+m13ig4h9FjsEXEX67rVRdRpwDVhrh5rZHQXzkxfJUXFORPwyRtlpSsMJdmUk6yWUqtMPmGogEGtmPXDH8NcksWWZB8xkaRh6agFH6LhM5u5yyuWj/wAMy4kK5bSryLTBdIPl3I1NY3PQG/SsOPI+ekaNNeU8MNGpWYMreICLBNURd3W9WemNPFcW8cM0VDm7Mj/kAgDFETiO82jVQbhbwxYyJL5O8YbepI7SnPCtzpy82bjCpoDWQdZIGk9egs7gf647tzZljE8iPqKbeH0Ym6Ao7gE/vdK3wcpZ+eeEyTAAE+QhSuoDq1X8t7L6gXvYxnaX0nzEEb/pVpU69FvjgRBi+pIuIOcC57FXGSjKIiO2plUAtVaiBRNe/XEL/G4fxIylkS6PEqjRG/Q9+h/I4hcafOGaP8ME8IDzsxUhiSB0vVSgE7Vd1it5sysi5rLZmHw9f+xp203vY+oC+KSLB9NzhaRY5xD7CDfnBI63t1Um0m+UucLgmxyImJ2khWfMfMAy8kMOk/tifP8AugDtf8W429MWCZJWSTXbJMtMjbrRBB2/mB3+2K3iMkkjQjwYp4xIpcE0U3+db2Omya6kbYs+M5YywSxK5jaRGQOBemwRfUdL9RjGGzUNV0iBEG0JJEBvusVlTN8JzU0OTZpstHUhgc6iEbcsK32NjUN/UGsbFy5nBNBFMoIWRFcA9QCAaxnec5fzKNDBmJZcxlp3ETTB2LI37qlWDAAtS6rI/QHTuGZNIYkjTZI1CLv0Cihv7AYpScXX0+7LRxTaLQ3A4E6wCBkNTmZubCOhCsMGDCFkefXlzrZZMoTGJXh8QSCyUYqW06QANmNaug+2LhrjMCYv2WenSfUnCJgSeibOOzMmXldTTBDR9D64pPhzn5p8q0k8hkJmcLYApRQA2AvcE2fXDBmgrqUcWrbEHvjhAsOXiPhxhVWzojXuT2UdycTI82Im0JxVZ4Bp4fNiBm2URG+Z9lYsaxyv7/3+mI3D80ZF86aH66NQYgX5SSNgSO2/1PXHDPtmRNCIUiaIkmd3YgqANtIHUn322PS7x1rg4YhkoxeFQ/E/JTPk1MMbSmOZJHiUkF0UNYFbk2VOw7dMLnKPFuHZydAkQizKGwknzWvXS1+aqO2x26bY1c4WOY+SMpnHSV00TIysssflfykGiR8wNVvuL2rDqra7hT8OTGdiR6jI5JkiFDHTCHwnkyeCqzV6SCpYs2waxY2G4FHDyrjpYsdcVrMpsIDH4uxH5XKrGMjC8OnkRHqq7jbSiMNCAWV1LDraavPXckLZA7kVhTm+KHD/ABNMc7S+vhxStX/L/TDrn8r4sbR62TWpXUlBhfoSDRwvx8IlysMSQaJFj1l9erUR5imm2o1sNJIHoVxncGsY6p/1a0ZgSZnLspYoNxa90x5WcOispBDAEEbgg9CMepyQp0gE0aBNAn69vrir5bEghVZCrEAEMkfhKQboadbgEVRpiOnrj7k+HSJmJZGlZkcAIhZiF7nrsN+lDp17Y604hITMDXAnFpIzv9F7rPeZ8qMxno8u8ZMsaeM0m62W22IPyKVAG5327b3/ACdy3LBmXzL5kv4kegodRrcEHUW3qiPl74UPjWUM0BCuHRTrkTqqk+UAWLINnqOvvty5bXjEUa5jJ5hM/l+8TsSxAPmFONSsPRWP0PTGptN1Hh2tGRvJFzc6/FluqVX+A1kAA8rm51vbS0LX+JmYqFiKqzbamUsB9hW/1NfXE7p9MR+H5xZYo5U+WRQwv0Ivf3xLxkDSCZP8LAdl4vfHoDFLxzmGHLUjMPFdWKLRN6R1ah5VuhZ9cLHJXFZs2YpY2lUAXmRIxdPE/fjVSf2ZB8w07UV2o4MV4Cszh3FhebNvBIsSNJ32/UkaFgwYMMoLlE5N2CKNb1v77Y64+Y+4EKk5uzTR5Od0FlV3+hIDH7KSftiFwAImXVUUrsGYkVbMqsSD3HmC3/LXbDFPEGUqwBDAgg7gg9QfbCBzB/iOSiEeThingQBYy7EPGo2CtbgOBsAwN1Vi9z1aG1CaPgiM5nKbR0teOpTRkM3HJK0RcawurSGF1dXXWvfHLmTlPL5yERShtCHUoVtNEAgdvQn88ZxyRNml4isudNTOfC0+UaUIJUALsBrPffbG0Y4uV6BpYb5iff8AgHpCyvhmcy2VMyQcNueNisYRdTSbbM0zfKGBu2PcgWesjlHkR5EMueYq5laRIYXIjS1A3FU7jcajdVscLvHebm4fnJ4ZfOqMzIoIZiGJKg/w7Ede2/cY2PhasIY9Yp9ILAdmIsj87xnpsLKxcJ6+4jkLocTTcC07EETnulf4jCeHh0jZeUoY0Otzu2gI24PZr07/AFwncBnj/wAJ/Gu7vMA0umQ2fFQEeTvTEDvRFA9MavxbIJPC8Mih0daKnof7NYUsvlI5JoPIpRBoVKGlQSNwKrYAAem+OVaRLg4cv57am+YCi3Mg5H4Xjlr4b5WPLxmVWaZ1DysWu3ZRr7dNV7e5wyZ3KmOBY4JBCYguksNS0NtLDbYixt0NHtWLrCzmOORNmHhWVWeP5kBBIqrsfU/rjU97nsDHOkbFcay5cBfX+VIyXAYlZ2epGkXS+pV0m/mpa6MeoJOKvhPOGXlZoCnhrqMUZBBRhekKaA8J620MB6Ak4lScYAJW9wL+39jGaZ7nm+JVBFl0kBMRmkB1PR3BII07ggE2enrWNFGHyHgmwAOKI0Gemn83S16rzDi7LkTYD4At6LXI0SFAkYpR0HX9TucSsvGkiKWVWo2LANEE7/UYyjOc5sz5hGlMZDKkSRBWNFSfELMpDbgitqqutHGi8kS68jA5s6lLWRV2xN179fviD/8AYhxvrv8Ad0zWEU2uDfKcjp27L5x/MeCY2FBfOWUAW1AdPpv/AH0ostw3NZnVK2bJSRT4cXmjUKSCGOjS4OkdDfzHfHz4r5lVhjTUUeTUEYWNxpNEjcA9PTCx8P8An0M0cLoQjXplLdCegIrYE3vfU9PR2U3uY6wINoLZMamf16rRT4YuZ4rZkHK9xFzzA1HNOWey86LEJaGXjHnXLLIzeXp3L0NjSizX2MMw5HiMqJonCQoNNKY4iLFLRFhgKoUpo7dMXa8WjljenXTem1kU3e3VSaJJoDrhBiymfhcRRcQjjRR5f2CuxUbWwJ69LIOJNwOpw7tPz8D9J28QRLgYcMogAbnLPYzPOwjXlIArGa8cyq8L8PMKS4eZnl9dTPq2HYUSn/De7Y4yfE+CH9nKryTozRuIkFWprUNTCg3XTZI6e5q5s5Lxd2/D2apCsgK+GhPX+Ft7Jo3sB2GL08dN2Ii2R6FX4Bhp1cTyGtgzIkEERH33NlLzHH4o83NmXnqC2dSGNOAiqoAvzE3YHqL7YrMjzXxPMyGWG4oQCyqY1ZSBda2O/mIqwQB9sOo+GeTcReLHrMQ2Bkk033Phhgg1HcgAA3iRzXy/mHyxjynhhrXY2vlG9LQoGwB6VeFYWY+U67Jf8ik+qzE2wDW9hmfmPddeWuZcsVWN5YY8y41SRhv3+/U9+oBN0RiVzF+NRF/CBZKNvqYBq/hUEaa+pvFPyTJl0imj0aZY20ZrUKZm07sb3KEXpvahix5I4n4mX0lXAiOgF+pFal677IV37ij3wVaBh0SAI9DkR7eqz4mNf4tMAgOsDeczl0EHsrPl7MTvEGzC6ZLO2kqaHSxZ367jY7Y8txg/i/wwhcgJqaToq30+oNVfr0B0uV88b5hiywGs+ZvlX/ufQYpeE5+aScyxzmRGrXE1aQPVSB5SL+/f1D0eHd4Zc4WgwTIk7/qbTErzuI46l44pizif9QJgfepAuU3zoGUqSRYI2JB39CNwfcYXzy8YIZPwhPjOB5nbr5gTZ9a1b9d8WWdnhT9rKaC1uSxA366egrqWrYdTQx1zfEY442ldwqKNRa9q/wC99vW8Z3OlrmTmLrYC/AabSYdYga8ud1UcrZXPI7/ijGylRpKE9b7g+39MMctUb6VvhZ4fzrlZY2ktkCfOGHy+nT5r7ab+xxzbnKLXWlgu3UUaIFNuR7iqvb7Yz8M1gApUjOdszueqVnCPpO/xw04hNszbPrCZMlEiIqp8gHl3LbfUkk46TSUpNFqF0Op9h74q83xImLXBpkPUAmgR7e/pdD3GOeWfMswcghSB5KG23rW++NAZhba2nTslydhIuPsfwoPFuWo8yVkYaGNaxeoEdwD2IGwYbe3pH5k4gmTyrQwACTToRVryAj5j6UDYvqSPfF7ms74YBdWAsC9JPU0LoGh7nYYzTJ8O4pLmH1COOpdbZiQBkNHbw0u2FBaugAKu8aaL8QaKzpa3TKeX3pkvQ4Z7HEHiD5G3Dd+QP55WyT9yZB+GyWWgmapCnRtjZJbT/uggfbF9JMq1qYDUaFkCz6D1Ptiqy7Qz3C7+LJAVZiRpN9QwqtjuNtqsG98SeK8JizAUSrq0HUpsgqaqxXfGdz8YxC5M9OyxA4qh8QwOQk87Ejtf8XX+bODF87kcwgupGhlXsY3jdiT7Kyg/72GXhvD4oE8OGNY0BJ0qAosmzsMQ+FcBhy7s6Bi7Ci7uztXoCSdI2BoVdD0xZxSXexGk1v8A1+4rCjmhx0Bt6e0n5XbBgwY6lSFzhNn0nL5cyKiqKpdaN3NiiAbNWa6bHF3ydns3NBrzUccbE+TRY1L/ABFTem+25vrtthhwoc785Dh/hAwNJ4pO96VABGrsbajYH645R4eo+rDJJOn6/QWmvxbDQawsaC2PMJmOe8m9+1lK5x5gORRJ2UHLhqlNEsP4dIG25sb96HfCdx6DiHEoYsxDLFDC6iSOEk6qO6lzpKlq3roL++Onxlz4k4UxRgyu8ZBHQjUCD9OhxM5IzA/w/KKO0Kd/5Rf64u04WSWg5i4meoP6WB1MOkEmDpp9OyzDjEnEMpOuZzAYsGU69iLFUPLt+6Pr9cfpDLzB0V1NqwDD6EWMIXFlDAhgCD1BFg4Z+TZbycQpRoBSl6AKSFA/3QuEqPD3YgInb4Wt9V72Na4zhEDos+505L/Ecdy0u3hyBGcd2MROq+1aFQffGu4iyZRTIkpHmRWVf97Tf/SP1xA5s4kctksxOvzJGxQerEUg+7EDE1MmVc4SOGZNhxN1BKxwhmC0ADrC6SPYamFfy+2L3k/iZzOSy87AhnjGsHsw2b/mBxPTJKJmm/edFQ/RSxH/AFn8hjoSkSpDsACT0G+MT5UhzE2fzM7eGis51FUWjq82kEebUt0xPf12xpvP2eaHIZho9pGXwo/80hCKfsWB+2Fvl3LhFVRvXU+p7k13Js/fDB0IIlM2Q4ZFeoxhmqrbzf12x7l5YyRDD8Hl/ObaokGo+pobnc74XeZOJ8SSkyGT8TYapWKEfRVLjptufWq74quBcZ5gWY/isj4kB9PCVx9Cr19iPuOuFTxAmV64ryrl8oskkcRkB3IZRIygfw2NRHU1ufrh45QlDZOFh0INdv3jiv40dsWnK6gZWMD3/wCo465xcZNzulAAaGjIJD+OwP4fL1u3iEAet0Nq3v0xD+H/ACIkSkz+a2JROlL21Hua3IFAG+uGzn7Kq7ZVmAOhnZb7GgL+tXjtw/MLHGZHYKiKWZj0AAsnDCo8WBVmV3sEMJB5c1b8O4JloQRFloYw3XRGi39aG/3x0zuShb5o0PvVH8xvjM+KfELNyteSaCOHcAupdyb/AM2kfStq6nHXhPxDmEnhZzwmBHzxKylP8wLGwfaiPQ4m7C0S4hRcQ0S4qq4z8M2GbV8rKxEj7hwGMZ1XruxqUCz/ABDbr1GscC4PFlYhHGtAfM21ue7Me5P/AIG2F3kvj8WbzEwj/wDSUdavc9a6gbGro+2Gziua8KCWWr8ONnr10qT/ANsMX4gD9OfrmYRjLvNOce0x+T6lRuIcdy0DBJZ0RjXlJ336Egbge5xI4fxGKddUMqSAGiVYNR9DXQ+2MATMGcyPrPiMxLsd2s9z/e1UKrE3kHPvk85GpNnMTLE4Bq1bZSRd0HPX3+uOkQDOaoWAAzmNFrvNHDWeNpIh+0UWyAD9slEGM97onSb2auxIMjhsqsoIUUQD0A7D/tX5YucLsUmmV19GOFSTaF1zPLWWln8eVBIdCoEbeMUzHUE6Fjq3Jv5FqqxcpEAKAAHoBWM/+JnPLZBI4oq8aYEhiAQijvR6knYXtsfbFZ8KOfJ81M+WzUniMyl420qpGmrXygA9Seliu/boZbEETFie323ynjivCZG/2Eoj1GnDjWtE7lVJ2aug+U2bHfFpBk1VQp89V5mC2a77AAH6ADEvGM89/EfNJmXjyjhVhJBUIrM5U01swIA60AL8ve6xy2tkplaxxHh8MyGOWJJEbqrAEf374WOMcFywkR2hViCNJN3YFAH+L2BvEjkTmb8fkVzBFOGZHHTde/3BB++JkKCSdAf3CX/IUP1IP2wCxnVMCQZFipfB8g8akyv4jliw2ACAnyqPoKF4s3cAWSAPfbHvCTx/kVs3IzyZ2Te9KhBSD0UXt9e+AoJkynNXBFg2PbFfxLIgqWUb917MP9cL/LnJb5OQOmccrfmQoNLD3F9fQ9f1tzxxcSBnZ8vBPFm5JzH1j0qCxk1fukAEkD5jQ7XtWOXNmdnzAlTLlopMqEnhdZa8U9SCmwZDuASfmXfY7xOeeHmQTRpfiRt4kWnqGqxXsb0/Q4pcllM1xjLRSBokmhkaN2pkaOq1AgdQRVptYrv0yvpvYMNIW+f10urNuMTtLLTOTuPrnsqk6jSxtZE/gddmX167j2Ixe4g8L4fHBGscSKijsvr3O5JJPqSTjplMysgJW6DFdwRupo9e1jr3xqnIHNRJEwpWDEHiPEooFDSvpB6Gif6DFVlec8lICVmsKdJOhxvQPcX3w0Kgo1C3EGmN4MKn5g49mctnGCAeB4ayP4oNWLDeGQ3StNivm/zbwfiG8k2WyUfhKcxPmEZYdWqlCtrYkDoFZdRGwLDr1L9ncjFMuiWNJFu9LqGH5EVjxkOEwQAiGCKIHqI0VAf+EDFm1g0tc0Q4ajlkd533HOSkdBZgjvr06ai0g6xAGTcY5W4lmTJk/ChiyhZakLA0FYG1AOokjqCAL77WXHh3LkWXSILuYohEH6EgV1A2NkXhg49FL4WqA1IjKwB6MAfMp9ipb70e2OWYOpbA6jp/2wtXizVfhMA52EToSd515rjGeG3y5ZZ+yzTnnikKSKrRs8qjUtMyAWe9HfdehBw0/CvjHjRzJpZdLK41V0YVtRPTT+uFznKSFJsv4woSFlDHbT0Nn2sgH01Xiz5JZIM8EBAMqMlD1HmH6K354xms4VcDjbT9ftVN2jktNxnXxp4sIsrHFe8j6j/lQX/1FPyxouME+M2vM8QVEkGmBAhB3AJ8xau5OoCv5cWcYEpGAFwnJNXwI4u8uWnifqkutP8AI46D6Mrf8WNRxhXwuzIyeehhLM34hGjtj0IAZdunVdI/zY3XHUOF5jNI3xQzYCZWItp8ScGrrVp7e/mZdvbHzgsfTCX8beNlM1EqprEQXqdlYnV276dB/wBcOnJvEEzMEc8fRx09D3B9wbGCyC0gAq4PMeSiYpLnctGw2KvPGpB9CC1jHo83cPOw4hlCfQZiL/5YVud/hbBxCT8Qj+DOQAx06letgWAIIIG1g9ANsL/CPgfokV582Cim9ESFS3tqJ2H2P2wIABGaa+N8x5Pes5ltuv7eP/5YZuVJlfKRMjBlINMpBB8x6EbHCPzFyFlDZhj8Fv5dwa/iU9T7iie94buQMsIuHwRgg6Awtemzt0wJVH54/wDQ+rf0GKXj2XMmQnUC/KCR7B1Lf8oOJvxGzwibKlzSFnDE9BstE+3+pxY8ITajuDgQscj4eNUMSxsE1a7XoCPW+2/1N7dDjrHxFDN4ZVdRJA3vpdXt7dMaenIMSyvJFNIivv4TedFP8l7qP5bIxwynIOTy8njLHqlBJDNexPcCzv74qDTgyJMe+91RrhBDxO3JJ/wozbx8TmR4wiTqyq1AamVrX811/pjZc3lxIjxt8rqVP0Io4x3nvhJVTPFL4DxESBh0tSCPcGwKrqexvDzyVziuajRJ9MWaqmS9nPql9b66eo36jcq92Iz9spNEWWfcS5Omy85YK4JPmZVLJIB0v0NfcWeuPvw/5CzB4k2bmjKQROZIy+xdiLAAO+lSbs/wgC963DHhnABJNAdScJEpw9w/C+SOFBJNACyT2GFDh2aErtIOjsWH0PT9KxSc/c5CQHK5U6lYHxZR0r+FPW+7dK2F3td8v5elX6D+mOAg5LkLLvjnIBnoSaNZdaHofEk3rvdfpjz8GnriEALKWKSEgdQNBIs9Pt9MW3xejzBz0Yij1qcul9Nj4ku43FGq3+mIfwwgY8Vic6gwWRHDdR5DV/aiPrjSAXMgRYfQdu6XC2MTtwI579N1vmPy9xcM7ymLYtKwZjtZ1EEX9drx+ocfnv8Aw0GViQFJdiADXck/X1++M6YGLp0+DcgPD5avbMOCCKIOiOxho4XmAuaAJ+dWUe52P9FOKz4eZRUykgUVczMfc6E3Pvtio59zMsEYmhrxY5EZL6WD0P1Fj746TJlBOIyVqJxlk/xmijleGTI5hJI7DKWSwR1HXDxypzHFnoBLHs3SSM/NG3dW/wCx7jfBxvlPJZs6sxlkd60690evTUpDV7XjgK4k7JfF6KV1RMnMWcgIoZCWJ7AA3Y7/AJ9N8S//AKpQiUwvlpo5F6q/lI2vextthm4BynkslZy2WSMnYtuzV6amJava8QufEyX4djnI43tWWMMdLEkfKrfMt9yD0w3lmy60aET0+lK/ElfPTCaCYwq1Gx5j8oogg1/reGnl3ha5SORraWSRjJKwUAu2kDZRSjZR99z1wk8i8Pkky0MiSNGzIvVdQAGwoHttYu+uNQySEAA7n1xnaLugRzzB5xP6XA9xOFwiOl/S/qpGXlDqrL0YAjYjYixsdxj2igdBWIHHc8YMvNMoDGKNno9DpF1+mIHLXMi5tpkEbI0Oi7IIOtdQI79u4xqFF5pmoBYWlKXNxYdVY8T4VFOAJV1VdeZh1q+hHoMVsXJXD1FfhYz7t5j+bEnDFgwkq3jVMODEY2kx6KGufiMphDr4gXUUsaq9a61/qPXFFzlzaMiFAyuYzEkg8ixRsVv3cA6foAT7YsOD8Cjy7OylnaRixaQ6mF9VB61e/r6k7Yt3W8cKV+AHyEkWz3191gGXn4nmMwmVkaZGO+lyxIGktbsTe4HqN9hXTGqw5zNOFKLl3YACWPxSpRu4sK1b3sce+P8ACJ3kiaGbwwrW61eof6jeh03x4yfAIod4Y0jlLX4mka2OrUwZtywYAg2e/wBMJXqOqPDnTDR/6klx/wBiBkJEDCLWGt0MaGi0X5fZ6nml/j/LjSZiPM5kAohCpDH5gtn53ZgNW9bBey9aN13FeBlZ0zMUjRyxm1IpluqsqeuxPpd40zNQhgQQCO4O+FzjERCOyrbANSnayLr7E9/fAGXJP37aEoJnkkjj3xBz2WiNyq0oW/8AZKBuaDHbp7e2KOTKjN3mFc1NqkkKi2Zjvt6UbGn2oViHwALmkl8Rg88jadMnvvt1odRW1acMfJnKU8Bb9xWYeQtqXbqwAPU9Kse/QDGl9M02S11xtn72IB7KReKhALCAQbmCDne2W0b2Ubh2UKLDJIw8VG1Rs4ANg2po96ANe2LnJc6Z9zI/jqYgfK3hoOgGretxd7+2Lbi/L6yaGN2mogCt7FEY5QcDYLRAXaglWB9fU/Tb69cZzUIOHCSd7R/Z7RNlRrSIBNh6/r0Sjx+bx1mkpZ5ZBrIUatRGheiG9gF6V0x75T4lnsuyP4QEbfPGV0KABtQPmBuhfphuy/D4YGtzFGzjqSFuvr9cTX4csi2jAj+JCD+o2w9KocBDmiT7ckz2Ozkx7L3H8Tsih0TtJA+3zRs4O3ZkB2+oGPec+KvCkH/7Wo+ixSk/9FD7nC7zBymmYjKMp6ggggEEehINX0++KnKcjQJRWHf1fzH9bA+2ApvJGqicy/FR8y3h5PLS+Edmc/Of8oWwu19yfpjrwCfNeAhXNShCPKsbuiqPQDV636YicwQaP2GWUtJJ5GI3Iv8AcX3Pc9h+jpy/wNcvlFDNqEanWV81MCS4UDcnUSKAs0NscwTBValF1OmHuETcdN+X9pS4lk5ZE8OaaaVTdeLK0lWNwNRPbFrylzDLk1ETKZYl2UE+ZR6Bu49AfzAoYv8AifLqzGB1YaEfxBQ2YaWA+4JB+ljvhL5j4hEHeBW0EN4bFgRZuiFAGqvev03LMYXuXKNI1PK08zyG/PstH4d8R8hKhbW6hSQdS3VH+UkV3v0xC438SsnGwjRJJpG6KoUe+9nUP+E4yDN8p5qDTNl9c0T7UoZGomqrrR7H6dMN3CuRipDu1OPMFU0Afc9T9du+Fa4EpzRpAYi/2v8AfsJb5o4tm808cs8ZSLV+wy8d7sNwzkgEmvUdjsN7ts7y7LMBqIRaVqG7A1Zs9Nj3F9MSP8JzBkhjzmZjhaYkIgt7qtj0RSbAB3snvh+znLIlh8FmcCl8ykK3lrfoR1HSsaXtpjAA64OYB+YnpZQqUg0SDM9QPUgarLuKcX4nkUITN5gx7aHJ10f4Truh3FY58P4vmM+yw5yZ3EiEx+YhJNJskAUA69x7Y0nimVy8a/h5AXLIBoCliwPlGyjqSO3Sr2rFDleH5Th8scDkInnnMspPzEaAqUOoVqJ22HvjK6sHvDbTlYZ/u1ydENpjBaZ+5dEu8BR5I2U1qVdjV79N99+2HvhvOIQKGysgoAWWTf7A7YmcT4UY0MkUCs/cAKpIPXckD0O+FvM8Uy6wmY7kbMiFXo/wlgdP64rSoucMNNs9Pv5XeJcwnxRDW7SPxn+Fwz3Mn47iBj8FoDHCuz02oB2sgjavOtff0xacszSZeQSzICVZ6Ckbqb0/p+gHfCyOIZmOSLNyQqkcoaNEKkkKNJst1BJIPQigdh1w+ZaDxI1YrpJFld9j37bi8K8hrjTkT+PuqU03BjahFjMc1af/AO2X/wBh/wAxjK8/wVpZGmntYo7kpSSaFkAVv+W/p1w28NlgmZxHPHIyncKw8oG249L79N8S14eJgssEqkra2hDIw7qexo9D1H3OO03Qbeq6KrqQJA0jn20lU3L3xCiy8Wj8PK3iOSDaDqAADudzpJxV88c3x5tFy0UT+K0iHqDWlgTdewOLbO8smeNYvw5y8ayBmB8M6gN6XQx6mtzXfriNnIosvmREmWZppU12iqLAJ6keYmx0ruMWDGudhY0zfUe5yUHuE4mmG88/g+oS3w7JZqDOCfLuUoDUVYC7BFFf3hsGoisNfE/inmsr4fiQRyKxosNSEdPQkE/YdMMScIGn5avev9cJnMPJ82YmIO0VCmJ+X1CqOrWLs+o69MZBDTlK1siofOQIHrGnXTsrSf4lZucFcqMuj6QRqDv1G1GwP0PUYhPwOfNqWzMvizOgUs48o31EAD5d+4Hbp1tf5R4E+W4mMpOmrUrPC+9bb6gOg2BB9CPezsmS4bVbYpMGyUuDCCz4zSpnuBzrwx4hK3iUNRvUQusWoNA0F79dvthKHAw8bPluLTtXYRuBf1EwP3rG18VzUOWgeWdgkSjzEgnqaAoCzZIFe+Ml/wAGykiN+FbMrEaAUuF39drJB9CcaOGY6pUJIJHKAJ56i0RC9H/57PHe7EwkZ2gC+5OQ6X2Vh8M1zU6Z/KzZmaVHhMatKzOFZgR5dRvobKg+nrjQOVeWvwZkdpdbSJEjUukfswwvqTvq/TGV8lcjTJnop1i0RxOGLuaJA9B81n6Vjc7vDcRUczFSaRhNyBfLmsPG0WNrkti2xmO+q6F9r67XtiDwfiSZhC6BgAxXzCjtXv74sF6Y8RwhRSgAegGMak0sAOISesddOn0rpjyTWPWKqbiqjMrlqGp4zIN+wIHSt/z/APDNaXZbE9hcqZIGasdP544nLrrVyLZQQD6aquu29D+7xIHTHl76CsKurxKmIOdyetSOl4peNy8RSEGIIZWmANLqCJpaz2/eC777Md/TlmeZc1HpjXJtmJKAZ1DIpPrVNQ/3sWp8O+oJbHqB+T/alWr06NTw3GTyBI9QEm8O5bkyvHUGkGPNRSPYGwK0WNdvNp//AKHDfx3jYykqIYWKka2fbdQabT6stgkHt9bF5wbLytU+ZCCaiqhB/s1JBK3uSSVUtvXlHpiLzHmctrigmjMjMbAF2o+XVYo7kgUOu/phQxz34W3PJa+CwOqDEwkGbZHI3z0zgn3XROFxSumYDaxpBTe13GzD7dPriPwfx3aVZ4AhRzodd0dSTpq97AoHau+16RdcM4dHl4lhiXTGmyqWZq3vqxJ6n1xE45zBl8rG0krgaaGkEFiWvSoHqaJ+gJ6C8RbTEwwZn1J+VJjWiQ1ueuufXXnPLJKnOEETZmGIhydDMxR9Glb2O6kHo35YaeHZOOGOKLV+6K1Eam6We1mzvQ74T5uXZOIu8r64o5mAa2KsYgK0qO9r3O1knfGjhKWloUKF742cTTbTDWA+bXW+23ouuHEsJp1aktGTBcN7xBJmYBIblMyl7hPD8x+0bMujam/ZqiaQiix1sk3sdz/oF7nvmBMsFhiIaeQ1Q30Duf8ANuAB73230XTjPeOcvxRD8Q+n8RHLPPFVAlWfVuTsSoIIvoaHbGStUN3xzgDYZBFKoKLg9zcQF43i8KTy/wArKoWaXUsxBoA0U1KQb9W379MVzctZ3RJlkkoKNccp6MRYCtt1Pf0IvcVju3M00nhRQeG+YdQzEHXGi38xK7aqry336na778fKP2DsRMFEhkijZlVCTRNggMdJGnfpi9Cs5hlusZjLnH8aq1fjKr21MYnEMumQEmxGl1Hh5czEOSkjhzN5llsO6goGrfSvYHpZv1rtjPMjytm4M2k8iu+YYeIzyP5BuAwd1BHQ/KB0Ar22jIhhGutw7VuwFA/QY7PED1GEqvc8lxNzqk4et4TCA0XEXEkWP79h3Qp+Y4kSNmhlfWWBMQVgKIBPmKkg3YIHTDRHkBjrJweBlAeNXC3RYX8xtjZ7k7k+uDg+eglj/YMCiEpQ20lexB3G1EexB6HCBpw/P2wTVBSLAaYdbMmIzOHLKw5z2S9zXyauZKzLYkRdIF7MLJr2Nk7/AJ+uLrlzLyCCPxr1V0bcgdgT3NdTi3LjpYv0wtQTRZIM2ZzI15iUnU7aQT2VVJNUtdPT2GGAm3smdxLncP4TyIaZFr3zE6DW+dhfJWk/BYnl8Yg69AS7PQEkbdiCxN9cLHN3L5zGZh/ZsyRqmo0a+c3v3NdftjrkczHxCbOQzbrA6iNbIBQrYkq6fUwaibAAFVuTecPyeYifeVXiO2kiildCpGxB7qRt1B7FqRFGoXAeaL2tpac56gDnNlHh+MqUaoc1siCJzztl8idVMz2RWRHRujqVP0IIP9cZvwb4cS5SYMM6rZaO3AkjUU2w8wumFX5tQqht3Gq6hdXviHxHJJNHJC/yyoyNXowIP33xxlVzQWgwDmpkDZKfOkSNl0lVgVD1YojcEdfrX54QuYOd86kbsuW8OAgxJKdmZyNnS/moAmgCB3Jxqz8tx/hGympirADWxtgQFCtsANiqmhV/fC1HyhLrgkz80Tw5JD4aoG3IOzMGHYBBtd6AO5uL6Y8QlhJ0H3mtrK7f8cMeBIJPre3cLNJsl+EjUgaJ5P2LJsV1MQfut6TR6YsuByZrKSZaOKUNNm5tLRaR4ehSBrO9gmzutbRm72xKznKOc4lmjOitDAZdQ8TSrJpS1tQSd2IG19bwwfD3kXMw51s1nNNxp4cFMH3N6mH8IALCjR87YXw6tN5Y60T6yvRr8dQqcKA10mG23sQe4IAymIvu2/4gPxZyrJo8oKOzD9oashV60Be57q221mLzXy8ZU8WOf8PLFuJSNQC9W9xtvt1oA4YMxweGSaOd4w0kQIRj2uu3SxWx7Wa64mTadJ1VpAs30++NDKjqbsTM/ua8OsKbgA0aCeu412S8/EdEUTfh8xMXAFxxrd11YawEvrfTteKLiXMoCLJGoUgsJI5V8wIPS1k0D8z1GL7MrmJcp/8Ab5pI5ZdLpIFDoFNGh2or3H/nGeZJc3FxCLLS/hswHkCklXO3zO253bTq+axYw1CiHg4ybCTFuucwFq4OhTqAmqScIkhtiY1kyAN9dkzclzTZ7MHNSwiKGFGjh2osXK6mDHcjyAbbb1uQcPqwgYHpV2UkChS/32x2wj3BxkCAs73BxkCBtsqfmPgaZvKyZV2YLIB5hRIpgw6+4GMxk+FmbjZhHxJlXbSV1qT7MA4AoVvZu+gxspOFLOc2xOXXLkSsncfL9j+99vscUo+IZawfd+Srw7K1SWUr77Rzm0JKi4HxjKIZU4jG6xgsfGby7dm1qdjvuHFY0zl7PHMZaKUroLqCy9abowB70QaPpWEvM8sZrPyB55DHCDemu1bFV6Bv5jde+HrhOQ8BNANqKCLVaVAAA7knYksdySccrNDIAgnWMhy5lNxFJtM4cQLuWQ5c+exVgBj7gwYksqMczGLBoWOhrfHTBgQvBFdMA3x7wYEIxxzGrS2n5qNfWtsdsGBdlVXL0MyZdFzDapReo3fViQL70CB9sWLRAkEgEjoa6fT0x0xScd48mVMYaKaQytpURJqrcWWNgKBqHU+uHh1R1hc7eqHvkl567aq7wq838uvMsUmXaFJYJDKomj1xkkGyQKprpg29EfcNWIfFMis8MsLEhZUZCR1AZSDX54TUH7t+JQDCyp+ZOLgtU/D5dP8A7Kyve/QdAT7Xhh5c58d5YcrmcvIkzqAzqpKiS2tStkqK0m7NWwOnTeMwyiJlMxPA82cj0OyRkCUfK1Bqj0hr6+m/3xs/JjxTwRTBHaSNRF400YSV9KgFjuWpvc+uNfF02Na3wo5nM9LWHqTvC21GcOxgtNswbh1omxEDYGdyEznFfm8hHKF1rdbg2QR60QbvFjjzpHXGUGDIWNri0yDCqeDcNhiVxFEqamJcgC3a9yxA8x7Wd8TsvlRGtJftqJP6nfHDhMEiKfEILGRyK7KWOkdOumr98WOEaXFoLs1NpcRLs1UTcMJzMeYWRhSaHXqrLuRQ7HURv6DFj+IXVp1Lq/hsX+XXHbClxrktMzIZHlchiNSsFOwrZDQKdLvfDALVTwVCG1X4QBAMT0FoOpvf0TbivynDIonkkRAHlILkfvEXX9T+Z9cd8nlliRY1vSgCiyWND1JNk+5xIOOyVAOIkAqrnyqLI0oXzsoRjZ3AJIFXXc71eMn5mzP/AOZiXMAGORVSEsCVQkjoLG5cUd+ji+gxsU8V4zz4xctNNklkiUmeKVPDC/M2tghUfcq3+5h6dQg56RzHTZJVbiHmy55QrM8AzYzsU8M9Rn/ag1YUUStfvBug9Ovvh6GF/h/E3Z4xp1eIOg2AVR5pD9WoAe498MOJ/wCUeI82cWnePz1S0+HbR8rRE3jZRfwieIJa84BW7PQkE7dNyBv7YkMMVp4ipzHgq1sFtlHYbeYnt2AHe/ysJYwwKkWCKI9QcTpuaZw7n1191Uzqk+fnxFLDwJGAYgFSu9HY0a69fvhugkDKGH7wB/PFY/LWVP8A6IH0LL/QjFtGoAAHQbDFStXEu4YhvgNcDrPaPle8eHcCr7mse8GOLIjHDNadDB60kUb6UdsdQK6Y453LiRChuj1rAhZbkoJ+FzLArNLkXcLHe7RFm2H0s/Q9diTbZwjlMJnBmzIXpWCqyiwzdW1XvtqFV+9ip5uXPsQkcUckeXkimUoDq02wooSQzKVuxWwFDfZ6yKuEXxCC9eahQ/sdMWAeyniBEOkRN7bjRMyu9mJjbAgTzE7qViLnM2sSF3JCr1IBbvXQAnErBiBmLffx+UhmLKj4rCM7lJYopKWZGTVRFXs2xo9L22xw5c5Wy+UWo1LN3kc6m+3Zft98MGgVWPQGGY5wbE9Y1+7J2Pe1pbOecaoGPuDBjiVGDBgwIRgwYMCEYMGDAhGDBgwIRha5u5abOeCBmGg8JixKiywIG3UAbgGzf0wYMMyq6m4PYYISuaHDCUy4MGDCplXZnhiSTRTG9UOrQL28womvWuh9z64scGDHcRIE6f3+SVwAIwYMGOLqi5zLlwF1FdwTpNEgHp9D3xJGDBhcIBlC+4MGDDIRin5pyc02Uliy7hJXXSrElQNxe4BIsWLHS8GDBMFETZI/Lked0/g5lmy025ErkyI9dkdTV1vpu6B9MMfAOTBFKJ553zEq3oLXpS+4BJN+9/bBgxrq8VVIwznfID49lkp8LSa6QPUk+xMJnWFQxYKAxABNbkC6/Kz+eO2DBjJELWuKQKGLhQGYAM1bmrqz3qz+eO2DBgQjBgwYEIwYMGBCMeCgu+/1wYMCF4ihVSxAosbY+pqv6ADHbBgwIRgwYMCEYMGDAhGDBgwIRgwYMCF//9k=',}}/>
        <View style={{flexDirection:"row",marginBottom:"-15%" }}>
        <Icon name="heart" backgroundColor='purple' color="white" size={55} category="invitation" style={{marginLeft:"2%",marginRight:"2%"}} onPress={SubmitHandler} />
        <Icon name="note" backgroundColor='purple' color="white" size={55} category="billbooks" style={{marginLeft:"2%",marginRight:"2%"}}  />
        <Icon name="card" backgroundColor='purple' color="white" size={55} category="cards" style={{marginLeft:"2%",marginRight:"2%"}}  />
        </View>
        <View style={{flexDirection:"row"}}>
        <Icon name="folder" backgroundColor='purple' color="white" size={55} category="bag" style={{marginLeft:"2%",marginRight:"2%"}} />
        <Icon name="file" backgroundColor='purple' color="white" size={55} category="notices" style={{marginLeft:"2%",marginRight:"2%"}} />
        <Icon name="contacts" backgroundColor='purple' color="white" size={55} category="Admin Page" onPress={SubmitHandler4} style={{marginLeft:"2%",marginRight:"2%"}} />
        </View>
        

        
        <View style={styles.outerContainer}>

        <View style={styles.galleryContainer}>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo}  source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/hindu-wedding-cards.jpg',}}/>
        <Button title="View Details" onPress={SubmitHandler} color="purple"></Button>
        </View>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/christian-wedding-cards.jpg',}}/>
        <Button title="View Details" onPress={SubmitHandler} color="purple"></Button>
        </View>
        
          </View>

          <View style={styles.galleryContainer}>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/muslim-wedding-cards.jpg',}}/>
        <Button title="View Details" color="purple" onPress={SubmitHandler}></Button>
        </View>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/SCROLL-INVITATIONS.jpg',}}/>
        <Button title="View Details" color="purple" onPress={SubmitHandler}></Button>
        </View>
          </View>

          <View style={styles.galleryContainer}>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/thamboolam-bags.jpg',}}/>
        <Button title="View Details" color="purple"onPress={SubmitHandler} ></Button>
        </View>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/wysiwyg/typostores/typologancee/images/addon-items.jpg',}}/>
        <Button title="View Details" color="purple" onPress={SubmitHandler}></Button>
        </View>
          </View>

          <View style={styles.galleryContainer}>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} resizeMode="cover" source={{uri: 'https://www.menakacard.in/media/catalog/product/cache/1/small_image/250x250/9df78eab33525d08d6e5fb8d27136e95/s/l/sl-2744_cover_pouch.jpg',}}/>
        <Button title="View Details" color="purple"onPress={SubmitHandler} ></Button>
        </View>
        <View style={styles.galleryContainer2}>
        <Image style={styles.tinyLogo} source={{uri: 'https://www.menakacard.in/media/catalog/product/cache/1/small_image/250x250/9df78eab33525d08d6e5fb8d27136e95/s/l/sl-3070_cover_inserts.jpg',}}/>
        <Button title="View Details" color="purple" onPress={SubmitHandler}></Button>
        </View>
          </View>

          </View>
          </ScrollView>


   </View>
  );
}

const styles = StyleSheet.create({
  container: {
      flex:1,
      backgroundColor:"#FFDEFA",
      width:"100%",
      alignItems:"center"
  },
  galleryContainer:{
    marginTop:"5%",
    flexDirection:"row",
   
  },
  galleryContainer2:{
    height:300,
    width:155,
    backgroundColor:"white",
    marginTop:"5%",
    marginLeft:"3%",
    marginRight:"3%",
    justifyContent:"space-evenly"
  },
  outerContainer:{
    alignItems:"center",
    justifyContent:"center"
  },
  button:{
    marginVertical:""
  },
  tinyLogo: {
    width: 155,
    height: 250,
    resizeMode:"stretch"
  },
  tinyLogo2: {
    width: 355,
    height: 255,
    resizeMode:"stretch",
    marginBottom:"-25%"
  },
});

export default HomeScreen;