import React from "react";
import { View, StyleSheet } from "react-native";
import TextInput from "../components/TextInput";
import colors from "../app/color";
import LoginButton from "../components/LoginButton";
import { Formik } from "formik";
//import { LoginForm } from "../app/LoginForm";
import ErrorMsg from "../components/ErrorMsg";
const RegisterScreen = ({ navigation }) => {
  const SubmitHandler = (values) => {
    console.log(values),
     
     navigation.navigate("HomeScreen")
  }
  return (
    <Formik
      initialValues={{ Name: "", Email: "", Password: "" }}
      onSubmit={SubmitHandler}
    //   validationSchema={LoginForm}

    >
      {({ handleChange, handleSubmit, errors, setFieldTouched, touched }) => (
        <React.Fragment>
          <View style={styles.continer}>
            <TextInput
              icon="account"
              placeholder="Enter Your name"
              placeholderColor="purple"
              keyboardType="default"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("Name")}
              onBlur={() => setFieldTouched("Name")}
            />
            {touched.Name && errors.Name ? (
              <ErrorMsg err={errors.Name} />
            ) : null}
            <TextInput
              icon="email-multiple"
              placeholder="Enter Your Email"
              keyboardType="email-address"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("Email")}
              onBlur={() => setFieldTouched("Email")}
            />
            {touched.Email && errors.Email ? (
              <ErrorMsg err={errors.Email} />
            ) : null}
            <TextInput
              icon="lock"
              placeholder="Enter Your Password"
              keyboardType="default"
              underlineColorAndroid="transparent"
              secureTextEntry={true}
              onChangeText={handleChange("Password")}
              onBlur={() => setFieldTouched("Password")}
            />
            {touched.Password && errors.Password ? (
              <ErrorMsg err={errors.Password} />
            ) : null}

            <TextInput
              icon="phone"
              placeholder="Enter Your Mobile Number"
              keyboardType="default"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("Phone")}
              onBlur={() => setFieldTouched("Phone")}
            />
            {touched.Phone && errors.Phone ? (
              <ErrorMsg err={errors.Phone} />
            ) : null}

            <TextInput
              icon="location-exit"
              placeholder="Enter Your location"
              keyboardType="default"
              underlineColorAndroid="transparent"
              onChangeText={handleChange("Location")}
              onBlur={() => setFieldTouched("Location")}
            />
            {touched.Location && errors.Location ? (
              <ErrorMsg err={errors.Location} />
            ) : null}

            <View style={styles.btn}>
              <LoginButton
                str="SUBMIT"
                color={colors.primary}
                onPress={handleSubmit}
              />
              <LoginButton
                str="CANCEL"
                color={colors.primary}
                onPress={handleSubmit}
              />
            </View>
          </View>
        </React.Fragment>
      )}
    </Formik>
  );
};

export default RegisterScreen;
const styles = StyleSheet.create({
  continer: {
    flex: 1,
    paddingTop: "35%",
    padding: 7,
    backgroundColor: "#FFDEFA",
    // width:"%"
  },
  btn: {
    alignItems: "center",
    paddingTop: 25,
    flexDirection: "row"

  },
});
