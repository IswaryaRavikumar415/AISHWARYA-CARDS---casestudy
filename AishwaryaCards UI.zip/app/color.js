export default {
    primary: "purple",
    secondary: "#4ECDC4",
    bgcolor: "black",
  };
  